function listarMarcas(){
    let cartasBrands = document.getElementById("cartasBrands");
    let template = "";
    fetch("http://localhost:3000/brands").then(r => r.json()).then(d => {
        d.forEach(Element=>{
            template += `
            <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
                <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
                    <img src="${Element.logo}" class="img-fluid" alt="">
                    <h4 class="title"><a href="">${Element.name}</a></h4>
                    <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi</p>
                    <br>
                    <button class="btn btn-primary w-100 btn-sm">Detalles</button>
                </div>
            </div>
            `;
            cartasBrands.innerHTML = template;
        });

    }) 

}
listarMarcas();

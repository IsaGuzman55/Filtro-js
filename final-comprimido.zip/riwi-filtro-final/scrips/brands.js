fetch("http://localhost:3000/brands")
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    data.forEach(function (element) {
      console.log(element);
      let tbodyMarcas = document.getElementById("bodyMarcas");
      let fila = document.createElement("tr");
      fila.innerHTML = `
        <td>${element.id}</td>
        <td><img width="100px" src="${element.logo}" alt="" class="logobrand"></td>
        <td>${element.name}</td>
        <td>${element.local}</td>
        <td>${element.floor}</td>
        <td>
            ${element.schedule}
        </td>
        <td>
            <a href="${element.website}">Sitio web</a>
        </td>
        <td>
            <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal"  onclick="EditarBrand(this)" type="button">Detalles</button>
            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal"  onclick="EditarBrand(this)" type="button">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="eliminarBrand('${element.id}')" type="button">Eliminar</button>
        </td>`;
    tbodyMarcas.appendChild(fila);
});
});


// Traer el valor de los inputs del modal de las marcas
let idBrand = document.getElementById("idBrand"); 
let logoBrand = document.getElementById("logoBrand");
let nombreBrand = document.getElementById("nombreBrand");
let localBrand = document.getElementById("localBrand");
let pisoBrand = document.getElementById("pisoBrand");
let horarioBrand = document.getElementById("horarioBrand");
let webBrand = document.getElementById("webBrand");


// Función para poner el contenido de la tabla en los inputs
function EditarBrand(element){
  
  let padre = element.parentElement.parentElement;
  let idEditar = padre.children[0].textContent;
  let logoEditar = padre.children[1].children;
  let logoUrl = logoEditar.item(0).src;
  let nameEditar = padre.children[2].textContent;
  let localEditar = padre.children[3].textContent;
  let pisoEditar = padre.children[4].textContent;
  let horaEditar = padre.children[5].textContent;
  let webEditar = padre.children[6].children;
  let webUrl = webEditar.item(0).href
  
  idBrand.value = idEditar;
  logoBrand.value = logoUrl;
  nombreBrand.value = nameEditar;
  localBrand.value = localEditar;
  pisoBrand.value = pisoEditar;
  horarioBrand.value = horaEditar;
  webBrand.value = webUrl;

}



function createBrands(){
    let newBrand = {
      logo: logoBrand.value,
      name: nombreBrand.value,
      local: localBrand.value,
      floor: pisoBrand.value,
      schedule: horarioBrand.value,
      website: webBrand.value,
    };

   
    if(idBrand.value == ""){

        fetch(`http://localhost:3000/brands`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(newBrand),
        })
          .then((response) => {
            return response.json();
          })
          .then((data) => {
            window.location.reload();
            console.log(data);
          });
        
    }else{  
      fetch(`http://localhost:3000/brands/${idBrand.value}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newBrand),
      })
        .then((response) => {
          return response.json();
        })
        .then((data) => {
            console.log(data);
          window.location.reload();
          console.log(data);
        });

    }

    // Borrar la información de los inputs
    idBrand.value = "";
    logoBrand.value = "";
    nombreBrand.value = "";
    localBrand.value = "";
    pisoBrand.value = "";
    horarioBrand.value = "";
    webBrand.value = ""
}

// Eliminar marcas
function eliminarBrand(id) {
  console.log(id);
  fetch(`http://localhost:3000/brands/${id}`, {
    method: `DELETE`,
    headers: {
      "Content-Type": "application/json",
    },
  }).then((response) => {
    window.location.reload();
    return response.json();
  });
}  

(()=> {
  let user = localStorage.getItem("usuario");
  if(!user){
      window.location.href = "../../login.html";
  }
})();

// Salir de la cuenta
function salirCuenta(){
  localStorage.clear();
} 


function SalirModalBrands(){
  idBrand.value = "";
  logoBrand.value = "";
  nombreBrand.value = "";
  localBrand.value = "";
  pisoBrand.value = "";
  horarioBrand.value = "";
  webBrand.value = ""
}


fetch("http://localhost:3000/pqrs")
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    data.forEach(function (element) {
      console.log(element);
      let tbodyPqrs = document.getElementById("tbodyPqrs");
      let fila = document.createElement("tr");
      fila.innerHTML = `
        <td>${element.id}</td>
        <td>${element.type}</td>
        <td>${element.email}</td>
         <td>${element.message}</td>
        <td>
             <button class="btn btn-sm btn-danger" onclick="pqrsDelete('${element.id}')">Eliminar</button>
        </td>`;
      tbodyPqrs.appendChild(fila);
    });
  });

// Eliminar mensajes
function pqrsDelete(id) {

    fetch(`http://localhost:3000/pqrs/${id}`, {
      method: `DELETE`,
      headers: {
        "Content-Type": "application/json",
      },
    }).then((response) => {
      window.location.reload();
      return response.json();
    });
}  

// Salir de la cuenta
function salirCuenta(){
  localStorage.clear();
} 

(()=> {
  let user = localStorage.getItem("usuario");
  if(!user){
      window.location.href = "../../login.html";
  }
})();
fetch("http://localhost:3000/admins")
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    data.forEach(function (element) {
      console.log(element);
      let tbodyAdmins = document.getElementById("tbodyAdmins");
      let fila = document.createElement("tr");
      fila.innerHTML = `
        <td>${element.id}</td>
        <td>${element.name}</td>
        <td>${element.email}</td>
        <td>
            
            <button class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="editarAdmins(this)" type="button">Detalles</button>
            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="editarAdmins(this)" type="button">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="eliminarAdmins('${element.id}')" type="button">Eliminar</button>
        </td>`;
      tbodyAdmins.appendChild(fila);
  });
});

// Inputs de del modal
let idAdmin = document.getElementById("idAdmin");
let nameAdmin = document.getElementById("nameAdmin");
let emailAdmin = document.getElementById("emailAdmin");

// Editar datos de los administradores
function editarAdmins(element){
  let padre = element.parentElement.parentElement;
  let idEditarAdmin = padre.children[0].textContent;
  let nameEditarAdmin = padre.children[1].textContent;
  let emailEditarAdmin = padre.children[2].textContent;

  idAdmin.value = idEditarAdmin;
  nameAdmin.value = nameEditarAdmin;
  emailAdmin.value = emailEditarAdmin;

}

function createAdmins(){

  let newAdmin = {
    name: nameAdmin.value,
    email: emailAdmin.value,
  };

  if (idAdmin.value == "") {
    fetch("http://localhost:3000/admins", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newAdmin),
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        window.location.reload();
        console.log(data);
      });

  } else {
    fetch(`http://localhost:3000/admins/${idAdmin.value}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newAdmin),
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        console.log(data);
        window.location.reload();
        console.log(data);
      });
  }
  idAdmin.value = "";
  nameAdmin.value = "";
  emailAdmin.value = "";

}

// Eliminar administradores
function eliminarAdmins(id) {
  console.log(id);
  fetch(`http://localhost:3000/admins/${id}`, {
    method: `DELETE`,
    headers: {
      "Content-Type": "application/json",
    },
  }).then((response) => {
    window.location.reload();
    return response.json();
  });
}  

// CARPETA:admin:index.html

// NUMERO DE ADMINISTRADORES
let nroAdmin = document.getElementById("nroAdmin");
fetch("http://localhost:3000/admins")
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    data.forEach(function (element) {
      nroAdmin.innerHTML = `${data.length}`;
      
  });
});

// NUMERO DE MARCAS
let nroBrands = document.getElementById("nroBrands");
fetch("http://localhost:3000/brands")
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    data.forEach(function (element) {
      nroBrands.innerHTML = `${data.length}`;
  });
});

// NUMERO DE PQRS
let nroPqrs = document.getElementById("nroPqrs");
fetch("http://localhost:3000/pqrs")
  .then((response) => {
    return response.json();
  })
  .then((data) => {
    data.forEach(function (element) {
      nroPqrs.innerHTML = `${data.length}`;
  });
});

// Salir de la cuenta
function salirCuenta(){
  localStorage.clear();
} 

function cerrarModalAdmins(){
  idAdmin.value = "";
  nameAdmin.value = "";
  emailAdmin.value = "";
}

(()=> {
  let user = localStorage.getItem("usuario");
  if(!user){
      window.location.href = "../login.html";
  }
})();
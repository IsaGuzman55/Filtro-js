let pqrsEmail = document.getElementById("pqrsEmail");
let messagepqrs = document.getElementById("message");

function elgirpqrs(){
    let pqrsSelect = document.getElementById("pqrsSelect").value;
    localStorage.setItem("pqrs", pqrsSelect);
    
}

// Crear los nuevos datos del pqrs
function CreaPqrs(){
    let pqrsEnviado = document.getElementById("pqrsEnviado");
    let type_pqrs = localStorage.getItem("pqrs");

    let newpqrs = {
      type: type_pqrs,
      email: pqrsEmail.value,
      message: messagepqrs.value,
    };

    if(pqrsEmail.value == "" && messagepqrs.value ==""){
      pqrsEnviado.innerHTML = `<p>Complete todos los campos</p>`;
      pqrsEmail.classList.add("is-invalid")
      messagepqrs.classList.add("is-invalid")
    }else{

      // Esta hace el POST
      fetch("http://localhost:3000/pqrs", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newpqrs),
      })
        .then((response) => {
          return response.json();
      })
      .then((data) => {
      pqrsEnviado.innerHTML = `<p>Se ha enviado su mensaje</p>`;
      pqrsEmail.value = "";
      messagepqrs.value = "";
      pqrsEmail.classList.remove("is-invalid")
      messagepqrs.classList.remove("is-invalid")
      localStorage.removeItem("pqrs");
      });

    }


}

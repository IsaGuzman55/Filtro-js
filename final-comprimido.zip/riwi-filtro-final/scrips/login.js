// Función con GET para verificar el login del admin 
function logIn() {
  let email = document.getElementById("emailLogin");
  let password = document.getElementById("passwordLogin");
  let verificaion = document.getElementById("verificaionLogin");

  fetch("http://localhost:3000/admins")
    .then((r) => r.json())
    .then((data) => {
      let resultado = data.filter(function (element) {
        return element.email == email.value;
      });
      console.log(email.value);
      console.log(resultado);
      if (resultado.length > 0) {
        if (resultado[0].password == password.value) {
           localStorage.setItem("usuario", JSON.stringify(data[0]));
          

          location.href = "./admin/index.html";
        } else {
          console.log("usuario o contraseña invalidos¡");
          verificaion.innerHTML = ` <p>¡Usuario o contraseña invalido!</p>`;
        }
      } else {
        console.log("No hay coincidencia");
        verificaion.innerHTML = `<p>¡No se encontró la cuenta!</p>`;
      }
    });
}

// Función para crear y editar las marcas

